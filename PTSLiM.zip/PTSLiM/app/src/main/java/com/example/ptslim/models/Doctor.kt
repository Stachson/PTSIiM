package com.example.ptslim.models

data class Doctor(
    val doctorID: Int,
    val firstName: String,
    val lastName: String,
    val speciality: String,
    val description: String
)