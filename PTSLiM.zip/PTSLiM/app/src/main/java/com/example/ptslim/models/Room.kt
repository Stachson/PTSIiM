package com.example.ptslim.models

data class Room(
    val roomID: Int,
    val roomNumber: Int,
    val purpose: String
)