package com.example.ptslim.models

data class User(
    val userID: Int,
    val firstName: String,
    val lastName: String,
    val email: String,
    val password: String
)