package com.example.ptslim.database

object GlobalData {

    var sharedUserID: Int = 43
    var sharedLogged: Boolean = false
}